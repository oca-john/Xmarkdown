# Xmarkdown v0.9.8

## 安装

```bash
./install.sh
```

安装后，可执行文件将复制到 ~/bin，快捷方式将创建到 ~/.local/share/applications。

## 卸载

```bash
./uninstall.sh
```

## 注意事项

- 请确保 ~/bin 已添加到 PATH 环境变量中
- 如果未添加，请执行: `echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc && source ~/.bashrc`
