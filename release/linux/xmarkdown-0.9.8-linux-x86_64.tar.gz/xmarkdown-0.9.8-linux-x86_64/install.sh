#!/bin/bash
# Xmarkdown 安装脚本
# 用法: ./install.sh

set -e

APP_NAME="xmarkdown"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BIN_DIR="$HOME/bin"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/128x128/apps"

echo "正在安装 Xmarkdown..."

# 创建目录
mkdir -p "$BIN_DIR"
mkdir -p "$DESKTOP_DIR"
mkdir -p "$ICON_DIR"

# 复制可执行文件
cp "$SCRIPT_DIR/bin/$APP_NAME" "$BIN_DIR/"
chmod +x "$BIN_DIR/$APP_NAME"
echo "  ✓ 可执行文件已安装到 $BIN_DIR/$APP_NAME"

# 复制图标
cp "$SCRIPT_DIR/assets/$APP_NAME.png" "$ICON_DIR/"
echo "  ✓ 图标已安装到 $ICON_DIR/$APP_NAME.png"

# 创建桌面快捷方式（更新路径）
cat > "$DESKTOP_DIR/$APP_NAME.desktop" << EOF
[Desktop Entry]
Name=Xmarkdown
Comment=A simple Markdown editor
Exec=$BIN_DIR/$APP_NAME %F
Icon=$ICON_DIR/$APP_NAME.png
Terminal=false
Type=Application
Categories=Office;TextEditor;Utility;
MimeType=text/markdown;text/x-markdown;
StartupWMClass=$APP_NAME
EOF
chmod +x "$DESKTOP_DIR/$APP_NAME.desktop"
echo "  ✓ 快捷方式已创建到 $DESKTOP_DIR/$APP_NAME.desktop"

# 更新桌面数据库
if command -v update-desktop-database &> /dev/null; then
  update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
fi

echo ""
echo "✅ Xmarkdown 安装完成！"
echo ""
echo "提示: 请确保 $BIN_DIR 已添加到 PATH 环境变量中。"
echo "如果尚未添加，请执行: echo 'export PATH=\"\$HOME/bin:\$PATH\"' >> ~/.bashrc && source ~/.bashrc"
