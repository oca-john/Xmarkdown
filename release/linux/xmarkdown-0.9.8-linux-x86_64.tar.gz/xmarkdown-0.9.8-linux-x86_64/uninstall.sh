#!/bin/bash
# Xmarkdown 卸载脚本
# 用法: ./uninstall.sh

set -e

APP_NAME="xmarkdown"
BIN_DIR="$HOME/bin"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/128x128/apps"

echo "正在卸载 Xmarkdown..."

# 删除可执行文件
if [ -f "$BIN_DIR/$APP_NAME" ]; then
  rm "$BIN_DIR/$APP_NAME"
  echo "  ✓ 已删除 $BIN_DIR/$APP_NAME"
fi

# 删除图标
if [ -f "$ICON_DIR/$APP_NAME.png" ]; then
  rm "$ICON_DIR/$APP_NAME.png"
  echo "  ✓ 已删除 $ICON_DIR/$APP_NAME.png"
fi

# 删除桌面快捷方式
if [ -f "$DESKTOP_DIR/$APP_NAME.desktop" ]; then
  rm "$DESKTOP_DIR/$APP_NAME.desktop"
  echo "  ✓ 已删除 $DESKTOP_DIR/$APP_NAME.desktop"
fi

# 更新桌面数据库
if command -v update-desktop-database &> /dev/null; then
  update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
fi

echo ""
echo "✅ Xmarkdown 已卸载！"
